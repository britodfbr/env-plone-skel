``collective.blueprint.jsonmigrator.statistics``
================================================

:TODO:
    need to fix statistic blueprint so it doesn't depend on other blueprints
    to report and add statistic data.

    Also reporting should not be only written to stdout.

Parameters
----------

Example
-------

