
import logging
from zope.i18nmessageid import MessageFactory

logger = logging.getLogger("JSON Migrator")
JSONMigratorMessageFactory = MessageFactory('collective.jsonmigrator')
