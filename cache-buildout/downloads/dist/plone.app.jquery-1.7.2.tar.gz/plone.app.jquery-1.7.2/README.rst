Introduction
============

plone.app.jquery adds `jquery`_ library to Plone.

.. _`jquery`: http://jquery.com
