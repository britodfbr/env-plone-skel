The Security framework provides a generic mechanism to implement security
policies on Python objects.
