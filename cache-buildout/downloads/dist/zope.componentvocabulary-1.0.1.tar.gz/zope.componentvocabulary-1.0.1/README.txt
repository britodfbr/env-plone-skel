This package contains various vocabularies.
