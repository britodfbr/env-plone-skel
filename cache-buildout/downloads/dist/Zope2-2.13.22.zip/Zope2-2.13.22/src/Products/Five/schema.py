# BBB

from zope.deferredimport import deprecated

deprecated("Please import from Zope2.App.schema",
    Zope2VocabularyRegistry = 'Zope2.App.schema:Zope2VocabularyRegistry',
)
