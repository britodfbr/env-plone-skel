# BBB
from AccessControl.metaconfigure import ClassDirective
