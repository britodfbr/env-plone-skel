""" Unit tests for ZReST product.
"""
