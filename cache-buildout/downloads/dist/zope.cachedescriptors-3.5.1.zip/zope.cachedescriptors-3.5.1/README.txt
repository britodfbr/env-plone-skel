See src/zope/cachedescriptors/README.txt.
