STATUSMESSAGEKEY = 'statusmessages'
