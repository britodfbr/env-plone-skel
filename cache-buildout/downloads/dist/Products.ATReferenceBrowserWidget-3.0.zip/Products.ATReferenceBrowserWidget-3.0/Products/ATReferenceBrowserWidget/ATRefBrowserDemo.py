import zope.deprecation
zope.deprecation.moved('archetypes.referencebrowserwidget.demo')

from archetypes.referencebrowserwidget.demo import RefBrowserDemo as \
    ATReferenceBrowserDemo
