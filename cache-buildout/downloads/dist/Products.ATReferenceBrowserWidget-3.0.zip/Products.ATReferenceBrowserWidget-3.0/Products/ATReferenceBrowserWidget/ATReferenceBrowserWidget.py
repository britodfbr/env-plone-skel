import zope.deprecation
zope.deprecation.moved('archetypes.referencebrowserwidget.widget', 'Plone 5.0')

from archetypes.referencebrowserwidget import ReferenceBrowserWidget
