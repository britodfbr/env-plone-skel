Introduction
============

ATReferenceBrowserWidget is an add-on to Archtetypes. It adds a new reference
widget that allows you to search or browse the portal when creating
references. This new widget inherits from the standard reference widget so you
can use all it's properties.

This package is now deprecated and superseded by
`archetypes.referencebrowserwidget`. You can learn more about the new package
at http://pypi.python.org/pypi/archetypes.referencebrowserwidget.

