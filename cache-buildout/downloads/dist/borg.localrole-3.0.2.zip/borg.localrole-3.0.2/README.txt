Overview
========

A PAS plugin which can manage local roles via an adapter lookup on the current
context.

