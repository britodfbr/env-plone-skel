# Configuration constants

LOCALROLE_PLUGIN_NAME = 'borg_localroles'