``zope.mkzeoinstance`` README
=============================

This package provides a single script, ``mkzeoinstance``, which creates
a standalone ZEO server instance.
