Contributors
------------

- Érico Andrei
- Cleber J Santos
- Gustavo Lepri
- Héctor Velarde
- Alejandro Pereira
- Simone Orsi

You can find an updated list of package contributors on `GitHub`_.

Development sponsored by Simples Consultoria.

.. _`GitHub`: https://github.com/collective/sc.contentrules.groupbydate/contributors
