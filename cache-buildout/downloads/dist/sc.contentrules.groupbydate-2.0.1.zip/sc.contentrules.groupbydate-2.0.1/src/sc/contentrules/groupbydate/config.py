# -*- coding=utf-8 -*-
from sc.contentrules.groupbydate import MessageFactory as _


PROJECTNAME = "sc.contentrules.groupbydate"

RELPATHVOC = {'../': _(u" One level up"),
              './': _(u' Same folder of content')}
