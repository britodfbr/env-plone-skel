*******************************
Plone transmogrifier blueprints
*******************************

.. contents::

This package contains several blueprints for collective.transmogrifier
pipelines, commonly used to import content into a Plone site.

Installation
************

See docs/INSTALL.txt for installation instructions.

Credits
*******

Development sponsored by
    Elkjøp Nordic AS
    
Design and development
    `Martijn Pieters`_ at Jarn_
    `Florian Schulze`_ at Jarn_
    
.. _Martijn Pieters: mailto:mj@jarn.com
.. _Florian Schulze: mailto:fschulze@jarn.com
.. _Jarn: http://www.jarn.com/
