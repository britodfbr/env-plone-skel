Welcome to Plone batching's documentation!
==========================================

This package includes facilities for creating a batched sequence.

It originated from the the PloneBatch module written for Plone which in
itself has been based on Zope2's ZTUtils.Batch.

Contents:

.. toctree::
   :maxdepth: 2

   CHANGES
   plone/batching/batching
   USAGE

.. automodule:: plone.batching.batch
    :members:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

