zope.processlifetime README
===========================

This package provides interfaces / implementations for events relative to
the lifetime of a server process (startup, database opening, etc.)

It is derived from Zope 3.4's 'zope.app.appsetup'.
