Overview
========

A collection of generally useful vocabularies.


Named Vocabularies
==================

* plone.app.vocabularies.AvailableContentLanguages
* plone.app.vocabularies.SupportedContentLanguages
* plone.app.vocabularies.Roles
* plone.app.vocabularies.Groups
* plone.app.vocabularies.AllowedContentTypes
* plone.app.vocabularies.AllowableContentTypes
* plone.app.vocabularies.PortalTypes
* plone.app.vocabularies.ReallyUserFriendlyTypes
* plone.app.vocabularies.UserFriendlyTypes
* plone.app.vocabularies.Skins
* plone.app.vocabularies.Workflows
* plone.app.vocabularies.WorkflowStates
* plone.app.vocabularies.WorkflowTransitions
* plone.app.vocabularies.AvailableEditors
* plone.app.vocabularies.Keywords
* plone.app.vocabularies.SyndicationFeedTypes
* plone.app.vocabularies.SyndicatableFeedItems
* plone.app.vocabularies.Users
* plone.app.vocabularies.Catalog
