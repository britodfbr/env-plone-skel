## Script (Python) "session_save_form"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=Introspect context schema and saves on session REQUESTs values
##

pass
