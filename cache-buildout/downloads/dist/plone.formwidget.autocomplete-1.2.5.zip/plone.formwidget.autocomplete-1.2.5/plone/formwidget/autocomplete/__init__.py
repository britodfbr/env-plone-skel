from zope.i18nmessageid import MessageFactory
MessageFactory = MessageFactory('plone.formwidget.autocomplete')

from plone.formwidget.autocomplete.widget import AutocompleteFieldWidget
from plone.formwidget.autocomplete.widget import AutocompleteMultiFieldWidget
