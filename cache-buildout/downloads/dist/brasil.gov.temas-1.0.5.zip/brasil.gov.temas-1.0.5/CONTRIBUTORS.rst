Contribuidores
-----------------

O ``brasil.gov.temas`` não seria possível sem a contribuição das
seguintes pessoas:

- André Nogueira
- Danilo Barbato
- Érico Andrei
- Héctor Velarde
- Igor Prado
- Felipe Duardo
- Rennan Rodrigues
- Rodrigo Ferreira de Souza
- Tânia Andrea

Para comunicar problemas e sugerir melhorias, `abra um ticket no repositório deste pacote <https://github.com/plonegovbr/brasil.gov.temas/issues>`_.
