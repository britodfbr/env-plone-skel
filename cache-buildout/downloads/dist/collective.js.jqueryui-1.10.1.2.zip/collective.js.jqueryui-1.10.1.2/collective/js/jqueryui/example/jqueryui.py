from Products.Five import BrowserView


class Example(BrowserView):
    """Simple Example View with jqueryui example"""

