Changelog
=========

1.1 (2014-02-19)
----------------

- Make the test setup independent from basic content types in the
  PLONE_FIXTURE.
  [timo]


1.0 - 2011-05-13
-----------------
- Release 1.0 Final.
  [esteele]

- Add MANIFEST.in.
  [WouterVH]


1.0b2 - 2011-01-03
------------------
- Use user id instead of user name to fix tests.
  [davisagli]


1.0b1 - 2010-11-27
------------------

- Initial release
