Overview
========

Record provides special objects used in some Zope2 internals like ZRDB.
