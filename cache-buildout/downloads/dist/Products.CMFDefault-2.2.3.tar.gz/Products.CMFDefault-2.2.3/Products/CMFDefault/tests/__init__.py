"""\
Unit test package for CMFDefault.

As test suites are added, they should be added to the
mega-test-suite in Products.CMFDefault.test_all.py
"""
