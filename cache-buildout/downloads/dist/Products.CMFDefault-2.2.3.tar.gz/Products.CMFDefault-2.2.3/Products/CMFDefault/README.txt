=====================
 Products.CMFDefault
=====================

.. contents::

This product declares basic content objects and provides
default implementation of some of the framework services for
the Zope Content Management Framework (CMF).
