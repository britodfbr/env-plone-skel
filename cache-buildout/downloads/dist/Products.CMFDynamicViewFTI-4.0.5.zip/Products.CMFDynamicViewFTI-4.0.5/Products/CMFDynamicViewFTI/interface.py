# BBB module will be removed at some point
from Products.CMFDynamicViewFTI.interfaces import *

