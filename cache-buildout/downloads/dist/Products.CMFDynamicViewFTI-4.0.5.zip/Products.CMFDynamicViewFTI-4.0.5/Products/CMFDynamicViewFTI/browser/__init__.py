# -*- coding: utf-8 -*-
"""
Browser subpackage
"""
# $Id$
