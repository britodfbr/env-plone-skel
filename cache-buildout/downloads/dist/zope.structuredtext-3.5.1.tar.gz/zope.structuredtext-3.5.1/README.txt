``zope.structuredtext`` README
==============================

This package provides a parser and renderers for the classic Zope
"structured text" markup dialect (STX).  STX is a plain text markup in
which document structure is signalled primarily by identation

Please see ``docs/index.rst`` for the documentation.
