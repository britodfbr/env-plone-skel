from zope.interface import Interface
from zope.i18nmessageid import MessageFactory
_ = MessageFactory('sc.social.like')


class ISocialLikeLayer(Interface):
    """
    """


class ISocialLikes(Interface):
    """
    """
