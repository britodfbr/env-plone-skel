Changelog
=========

1.1.1 (2013-05-16)
------------------

- Solve issue with VHM and tile rendering. Fixes 
  https://dev.plone.org/ticket/13581 [ericof]

1.1 (2012-12-17)
----------------

- make sure to use correct url of tile
  [vangheem]

- handle not found errors while rendering tiles so layout
  isn't borked
  [vangheem]

1.0 (2012-06-23)
----------------

- initial release.
  [garbas]
