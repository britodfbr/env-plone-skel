# -*- coding: utf-8 -*-

from zope.interface import Interface


class INITFLayer(Interface):
    """ A layer specific for this add-on product.
    """
