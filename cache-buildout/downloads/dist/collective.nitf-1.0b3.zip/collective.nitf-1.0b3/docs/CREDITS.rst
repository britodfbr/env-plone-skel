Share and Enjoy
---------------

``collective.nitf`` would not have been possible without the contribution of
the following people:

- Héctor Velarde
- Joaquín Rosales
- Érico Andrei
- Juan A. Díaz
- Silvestre Huens
- Gonzalo Almeida
- Franco Pellegrini
- Cleber J Santos

You can find an updated list of package contributors on `GitHub`_.

Development sponsored by Open Multimedia.

.. _`GitHub`: https://github.com/collective/collective.nitf/contributors
