Contribuidores
-----------------

O ``brasil.gov.portal`` não seria possível sem a contribuição das
seguintes pessoas:

- André Nogueira
- Cleber J. Santos
- Érico Andrei
- Héctor Velarde
- Felipe Duardo
- Rennan Rodrigues
- Rodrigo Ferreira de Souza

Para os testes do tipo áudio utilizamos o arquivo disponível em 
http://commons.wikimedia.org/wiki/File:Thunder.ogg
