Installation
------------

To enable this product,on a buildout based installation:

    1. Edit your buildout.cfg and add ``sc.contentrules.metadata``
       to the list of eggs to install ::

        [buildout]
        ...
        eggs =
            sc.contentrules.metadata

After updating the configuration you need to run the ''bin/buildout'',
which will take care of updating your system.

