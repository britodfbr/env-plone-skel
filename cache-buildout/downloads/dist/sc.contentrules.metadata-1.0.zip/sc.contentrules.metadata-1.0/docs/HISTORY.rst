Changelog
------------

1.0b3 (unreleased)
^^^^^^^^^^^^^^^^^^

- Plone 4.3 support [ericof]


1.0b2 (2013-01-15)
^^^^^^^^^^^^^^^^^^

- Test compatibility with Plone 4.3. [hvelarde]

- Fix package distribution. [hvelarde]


1.0b1 (2013-01-14)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

- Initial release
  [ericof]
