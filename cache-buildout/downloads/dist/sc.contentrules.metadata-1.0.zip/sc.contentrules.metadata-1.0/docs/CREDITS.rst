Contributors
------------

 - Érico Andrei [ericof] -- Initial idea

 - Héctor Velarde [hvelarde]


Development sponsored by OpenMultimedia and Simples Consultoria.
