todos:
- update migration view to allow selecting which migrations are to be run
- turn off linkintegrity checking & collective.indexing during migration
- investigate problem regarding versioning
- fix migration when using "atfile replacement" profile
- explain which gs profile to use
- add section about buildout-installer to the docs
- answer remaining questions in the faq section
- document administration & backup issues
- document "streaming from file-system" f.a.q.
- document at.schemaextender issues & caching
- document motivation for blobs & design decision
- figure out a backup solution for repozo (for the common case):
  perhaps using zope tids to stay in sync and rsync for the actual blob backup

