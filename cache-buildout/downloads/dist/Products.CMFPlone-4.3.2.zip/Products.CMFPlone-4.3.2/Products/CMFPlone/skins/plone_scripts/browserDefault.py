## Script (Python) "browserDefault"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
##title=Set Browser Default

# Deprecated script
return context.plone_utils.browserDefault(context)
