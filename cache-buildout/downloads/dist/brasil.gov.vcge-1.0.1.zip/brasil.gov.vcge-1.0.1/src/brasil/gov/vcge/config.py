# -*- coding:utf-8 -*-

PROJECTNAME = "brasil.gov.vcge"

DEFAULT_FILE = 'vcge.n3'
DEFAULT_FORMAT = 'n3'
NAMESPACE = 'http://www.w3.org/2004/02/skos/core#'
