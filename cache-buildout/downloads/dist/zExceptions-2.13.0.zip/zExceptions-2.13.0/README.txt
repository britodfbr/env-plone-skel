Overview
========

zExceptions contains common exceptions and helper functions related to
exceptions as used in Zope 2.
