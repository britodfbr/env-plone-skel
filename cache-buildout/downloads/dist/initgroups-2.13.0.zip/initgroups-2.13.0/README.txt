Overview
========

initgroups provides a convenience function to deal with user / group ids on
Unix-style systems.
