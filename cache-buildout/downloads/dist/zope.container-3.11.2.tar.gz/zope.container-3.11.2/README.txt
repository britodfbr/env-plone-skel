This package define interfaces of container components, and provides
container implementations such as a BTreeContainer and
OrderedContainer, as well as the base class used by ``zope.site.folder``
for the Folder implementation.
