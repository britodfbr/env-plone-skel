See src/zope/contentprovider/README.txt.
