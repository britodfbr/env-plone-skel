Share and Enjoy
---------------

sc.social.like would not have been possible without the contribution of the
following people:

- Cleber J. Santos (idea and implementation)
- André Nogueira
- Héctor Velarde
- Erico Andrei
- Mikel Larreategi

Development sponsored by:

- `Rede Brasil Atual <http://www.redebrasilatual.com.br/>`_
- `TV1 <http://www.grupotv1.com.br/>`_
- `Brazilian Government <http://www2.planalto.gov.br/>`_
