from zope.interface import Interface

class IDoormatLayer(Interface):
    """ Marker interface for browser layer
    """
