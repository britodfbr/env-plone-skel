Overview
========

This package provides a variant of the persistent base class that's an
ExtensionClass. Unless you need ExtensionClass semantics, you probably want to
use persistent.Persistent from ZODB3.
