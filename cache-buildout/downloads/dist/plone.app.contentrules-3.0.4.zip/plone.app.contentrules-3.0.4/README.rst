Introduction
============

plone.app.contentrules provides Plone-specific conditions and actions, as well
as a user interface for plone.contentrules.


git branches
------------

master(3.x)
~~~~~~~~~~~

New content rules UI.


2.x branch
~~~~~~~~~~

Maintenance branch for older plone versions