Object references that support stable comparison and hashes.
