# backward compatibility
from IValidator import IValidator as ivalidator
from IValidationService import IValidationService as ivalidationService
