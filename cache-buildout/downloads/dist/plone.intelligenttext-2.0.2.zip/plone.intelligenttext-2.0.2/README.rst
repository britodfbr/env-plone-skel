plone.intelligenttext
=====================

Overview
--------

Provides transforms from text/x-web-intelligent to text/html and vice versa.
