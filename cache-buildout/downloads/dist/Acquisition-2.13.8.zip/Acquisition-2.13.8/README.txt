Please refer to src/Acquisition/README.txt.
