"""The code here is taken from ATContentTypes, from which it has since been
removed because it is no longer necessary in Plone 3.
"""
