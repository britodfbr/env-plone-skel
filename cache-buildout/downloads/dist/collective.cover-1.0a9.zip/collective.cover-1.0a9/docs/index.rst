.. line-block::

    WARNING: If you are reading this on GitHub, DON'T! Read it on ReadTheDocs:
    http://ploneapi.readthedocs.org/en/latest/index.html so you have working
    references and proper formatting.


****************
collective.cover
****************

Contents:

.. toctree::
   :maxdepth: 2

   end-user.rst
   developer.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

