============
Introduction
============

This package offers a simple way to develop and deploy Plone themes using
the Diazo theming engine. If you are not familiar with Diazo, check out the
`Diazo documentation <http://diazo.org>`_.

This version of ``plone.app.theming`` ships with Plone version 4.3 or later.
It comes with a user guide, reproduced below, available through the theming
control panel.
