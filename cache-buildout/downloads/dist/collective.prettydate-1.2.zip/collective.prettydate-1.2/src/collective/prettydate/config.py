# -*- coding: utf-8 -*-

PROJECTNAME = 'collective.prettydate'
