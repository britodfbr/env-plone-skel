Contributors
-----------------

- Érico Andrei [ericof]
- Hector Velarde [hvelarde]
- Avianca (for the space between seats)


You can find an updated list of package contributors on `GitHub`_.

Development sponsored by Simples Consultoria.

.. _`GitHub`: https://github.com/simplesconsultoria/sc.contentrules.layout/contributors
