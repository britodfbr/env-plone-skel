Changelog
------------

1.0.1 (unreleased)
^^^^^^^^^^^^^^^^^^^^

- Add translations to plone domain.
  [ericof]

1.0 (2013-04-13)
^^^^^^^^^^^^^^^^^^

- Support Plone 4.3 [ericof]

- Remove dependency on zope.app.publisher. [hvelarde]


1.0b2 (2012-11-14)
^^^^^^^^^^^^^^^^^^

- Fix packaging [ericof]


1.0b1 (2012-11-14)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

- Initial release [ericof]
