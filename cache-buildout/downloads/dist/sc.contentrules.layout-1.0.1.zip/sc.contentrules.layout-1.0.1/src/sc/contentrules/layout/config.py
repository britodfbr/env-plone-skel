# -*- coding:utf-8 -*-

VOCAB = 'sc.contentrules.layout.available_views'
