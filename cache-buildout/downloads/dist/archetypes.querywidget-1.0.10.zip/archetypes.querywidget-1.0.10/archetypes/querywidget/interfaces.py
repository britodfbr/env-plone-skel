from zope.interface import Interface


class IQueryField(Interface):
    """Query field interface """
