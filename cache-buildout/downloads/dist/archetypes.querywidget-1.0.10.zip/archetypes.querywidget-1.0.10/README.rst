Introduction
============

Archetypes.querywidget implements a widget for creating catalog queries using an
email-filtering-like interface, as found in GMail or Apple Mail.
