Pasta JBot
==========

Esta pasta DEVE ser utilizada somente para sobrepor templates de pastas skins.

Caso outro template sem ser de pasta skins for sobreposto nesta pasta, DEVE-SE
abrir uma nova issue para RETIRAR este template desta pasta e mover para o
pacote brasil.gov.portal.
