This package provides an error reporting utility which is able to store errors.
