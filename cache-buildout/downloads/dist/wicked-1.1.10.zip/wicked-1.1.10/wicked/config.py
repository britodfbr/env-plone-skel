from txtfilter import WickedFilter
BACKLINK_RELATIONSHIP  = 'Backlink->Source Doc'
FILTER_NAME = WickedFilter.name
GLOBALS                = globals()

