from wicked.interfaces import IAmWickedField
from zope.interface import Interface

class IAmATWickedField(IAmWickedField):
    """an archetypes specific wicked field"""

