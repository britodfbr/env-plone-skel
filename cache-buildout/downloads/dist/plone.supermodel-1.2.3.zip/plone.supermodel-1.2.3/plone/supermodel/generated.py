# This module will be used as a faux location for generated interfaces
# by default.

# To override this behaviour, override the default ISchemaPolicy
