This package defines an ``IInterface`` that allows the developer to mark
interfaces as content types.
