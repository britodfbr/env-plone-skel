"""
backward compatibility module, don't remove it as too many products rely on it.
"""
# all current from atapi
from Products.Archetypes.atapi import *
