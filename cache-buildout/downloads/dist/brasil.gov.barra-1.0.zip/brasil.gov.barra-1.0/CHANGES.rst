Alterações
------------

1.0 (2014-03-10)
^^^^^^^^^^^^^^^^^^

* Oculta passos de atualização da tela de criação do site
  [ericof]

* Pequenos ajustes na organização do pacote
  [ericof]

* Atualizado produto da barra para ter a mesma aparência da barra
  remota (closes `#7`_).
  [felipeduardo][rodfersou]


1.0a1 (2013-07-22)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
* Suporte a barra hospedada no endereço barra.brasil.gov.br
  [ericof]
* Suporte a quatro cores da barra
  [ericof]
* Versão inicial do pacote
  [ericof]


.. _`#7`: https://github.com/plonegovbr/brasil.gov.barra/issues/7
