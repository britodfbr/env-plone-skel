# dumped at some point

queryplan = {
    '/folder/catalog': {
        'VALUE_INDEXES': frozenset(['index1']),
        'index1 index2': {
            'index1': (2.0, 3, True),
            'index2': (1.5, 2, False),
        },
    }
}