# This is an error: there can be no python module named 'static.py' when there
# is a 'static' resource directory
