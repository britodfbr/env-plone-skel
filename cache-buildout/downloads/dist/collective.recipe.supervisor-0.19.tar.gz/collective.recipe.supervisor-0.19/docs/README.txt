.. contents::

- Code repository: https://github.com/collective/collective.recipe.supervisor/
