collective.recipe.supervisor
============================

A buildout recipe to install supervisor