# Register the permissions with Zope
import plone.app.workflow.permissions

from zope.i18nmessageid import MessageFactory
PloneMessageFactory = MessageFactory('plone')
