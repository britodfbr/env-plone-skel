
============================
Auto inclusion of zcml files
============================

The doctests are organized into three files:

 * ``dependency.txt``: for package dependency inclusion
 * ``plugin.txt``: for package plugin inclusion
 * ``utils.txt``: for general-purpose utility functions

Read them, they're fun.
