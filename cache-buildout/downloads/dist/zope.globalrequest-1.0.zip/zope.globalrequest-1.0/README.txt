Please refer to src/zope/globalrequest/README.txt.
