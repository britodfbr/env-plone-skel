Share and Enjoy
---------------

``collective.z3cform.widgets`` would not have been possible without the
contribution of the following people:

- Franco Pellegrini
- Gonzalo Almeida
- Silvestre Huens
- Héctor Velarde
- Cleber J. Santos
- João S. O. Bueno

You can find an updated list of package contributors on `GitHub`_.

Development sponsored by Open Multimedia.

.. _`GitHub`: https://github.com/collective/collective.z3cform.widgets/contributors
