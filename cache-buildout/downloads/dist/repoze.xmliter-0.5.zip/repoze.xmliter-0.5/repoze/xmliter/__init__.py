from decorator import lazy
