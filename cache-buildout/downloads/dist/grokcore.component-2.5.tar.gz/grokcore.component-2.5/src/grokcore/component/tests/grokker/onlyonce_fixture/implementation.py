from component import Alpha

class AlphaSub(Alpha):
    pass