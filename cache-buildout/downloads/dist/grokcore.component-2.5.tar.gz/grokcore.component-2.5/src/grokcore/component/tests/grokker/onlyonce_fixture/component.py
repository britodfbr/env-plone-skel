import grokcore.component as grok

class Alpha(object):
    grok.baseclass()
