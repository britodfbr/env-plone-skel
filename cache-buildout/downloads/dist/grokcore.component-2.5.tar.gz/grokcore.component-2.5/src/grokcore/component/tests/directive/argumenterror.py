"""
   >>> import grokcore.component.tests.directive.argumenterror_fixture
   Traceback (most recent call last):
     ...
   TypeError: name takes exactly 1 argument (3 given)

"""
