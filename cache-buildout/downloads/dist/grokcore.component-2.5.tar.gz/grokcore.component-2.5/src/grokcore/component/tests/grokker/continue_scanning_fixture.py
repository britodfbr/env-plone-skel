from grokcore.component.tests.grokker.continue_scanning import Alpha, Beta

class AlphaBetaSub(Alpha, Beta):
    pass
