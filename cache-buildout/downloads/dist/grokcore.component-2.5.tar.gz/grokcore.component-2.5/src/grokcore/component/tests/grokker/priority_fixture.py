import grokcore.component.tests.grokker.priority

class AlphaSub(grokcore.component.tests.grokker.priority.Alpha):
    pass

class BetaSub(grokcore.component.tests.grokker.priority.Beta):
    pass

class GammaSub(grokcore.component.tests.grokker.priority.Gamma):
    pass
