import grokcore.component as grok

class Foo(object):
    grok.name('too', 'many', 'arguments')
