"""
This should fail:
"""
import grokcore.component as grok
grok.name('viewname')
