import grokcore.component as grok

@grok.subscribe()
def subscriber():
    pass
