# -*- coding:utf-8 -*-

PROJECTNAME = 'collective.polls'
COOKIE_KEY = 'collective.poll.%s'
MEMBERS_ANNO_KEY = 'voters_members_id'
VOTE_ANNO_KEY = 'option.%02d'

PERMISSION_VOTE = 'collective.polls: Vote'
