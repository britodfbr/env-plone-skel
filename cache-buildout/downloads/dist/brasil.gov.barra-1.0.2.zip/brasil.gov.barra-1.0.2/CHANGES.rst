Histórico de Alterações
------------------------

1.0.2 (2014-06-11)
^^^^^^^^^^^^^^^^^^

* Englobamos a barra com um div com id barra-identidade, que engloba também o javascript
   [ericof]


1.0.1 (2014-06-10)
^^^^^^^^^^^^^^^^^^

* Uso do plone.api para rotinas internas
  [ericof]

* Corrige o template para remover o script de dentro do div da barra (closes `#10`_)
  [ericof]


1.0 (2014-03-10)
^^^^^^^^^^^^^^^^^^

* Oculta passos de atualização da tela de criação do site
  [ericof]

* Pequenos ajustes na organização do pacote
  [ericof]

* Atualizado produto da barra para ter a mesma aparência da barra
  remota (closes `#7`_).
  [felipeduardo][rodfersou]


1.0a1 (2013-07-22)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
* Suporte a barra hospedada no endereço barra.brasil.gov.br
  [ericof]
* Suporte a quatro cores da barra
  [ericof]
* Versão inicial do pacote
  [ericof]


.. _`#7`: https://github.com/plonegovbr/brasil.gov.barra/issues/7
.. _`#10`: https://github.com/plonegovbr/brasil.gov.barra/issues/10
