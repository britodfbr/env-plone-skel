
Contribuindo
--------------

Em linhas gerais, este pacote aceita contribuições ao seu código.

Para entender como os projetos da comunidade PloneGov.Br são gerenciados no
GitHub, leia a documentação em http://plonegovbr.github.com

