Contribuidores
-----------------

* Equipe do Governo Eletrônico -- concepção da barra, diretrizes 
  de uso

* SECOM -- Demanda para criação de pacote Plone

* Cintia Cinquini [cintiacinquini] -- Coordenação da implantação 
  em Plone

* Érico Andrei [ericof] -- Implementação inicial em Plone

* André Nogueira [agnogueira] -- Ajustes de estilos

* Felipe Duardo [felipeduardo]

* Rodrigo Souza [rodfersou]

