import browser
browser   # pyflakes
