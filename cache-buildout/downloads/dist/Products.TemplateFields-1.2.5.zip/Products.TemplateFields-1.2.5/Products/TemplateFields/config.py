# Set this to True if field rendering errors should be handled internally
# and a 'an error occured' html error returned. If you set this to False
# trying to get the field value may expose exceptions raised by the template
# rendering logic
CATCH_RENDER_ERRORS = True

