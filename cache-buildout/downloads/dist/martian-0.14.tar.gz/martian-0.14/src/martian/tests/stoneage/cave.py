
class Cave(object):
    pass

class Index(object):
    pass

index = Index()
