
class Mammoth(object):
    pass

class Index(object):
    pass
