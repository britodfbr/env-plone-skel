from martian.tests.testpackage import animal

class Python(animal.Animal):
    pass
