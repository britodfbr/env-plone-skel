
class Package(object):
    pass
