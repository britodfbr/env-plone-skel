import animal

class Bear(animal.Animal):
    pass
