
def main():
    print "Hello"

main()

