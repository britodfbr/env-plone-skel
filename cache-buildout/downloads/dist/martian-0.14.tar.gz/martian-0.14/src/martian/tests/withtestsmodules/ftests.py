import unittest
def test_suite():
    return unittest.TestSuite() # return an empty suite
