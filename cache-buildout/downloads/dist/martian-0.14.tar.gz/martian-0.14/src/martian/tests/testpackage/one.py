import animal

class Whale(animal.Animal):
    pass

class Dragon(animal.Animal):
    pass

class SpermWhale(Whale):
    pass
