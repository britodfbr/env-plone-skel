from martian.tests.testpackage import animal

class Lizard(animal.Animal):
    pass

