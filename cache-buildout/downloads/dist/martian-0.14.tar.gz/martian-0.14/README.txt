*******
Martian
*******

A library to grok configuration from Python code.
