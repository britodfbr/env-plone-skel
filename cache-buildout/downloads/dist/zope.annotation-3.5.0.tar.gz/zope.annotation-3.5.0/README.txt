See src/zope/annotation/README.txt.
