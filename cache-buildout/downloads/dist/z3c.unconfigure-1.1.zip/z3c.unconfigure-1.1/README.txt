Please refer to src/z3c/unconfigure/README.txt
