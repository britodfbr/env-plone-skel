Overview
========

The Products.ZSQLMethods product provides support for SQL Method objects in
Zope 2. They can be used in conjunction with any database adapter to use
relational database data from within the Zope environment.
