Index intransitive and transitive n-ary relationships.
