README
======

See src/z3c/objpath/README.txt
