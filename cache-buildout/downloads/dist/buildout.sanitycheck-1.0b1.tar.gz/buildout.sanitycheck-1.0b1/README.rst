Introduction
============

``buildout.sanitycheck`` performs sanity checks on the buildout
environment, cancelling the buildout if continuing might
be unwise.

Checks performed:

* Make sure buildout is not being run as superuser.
