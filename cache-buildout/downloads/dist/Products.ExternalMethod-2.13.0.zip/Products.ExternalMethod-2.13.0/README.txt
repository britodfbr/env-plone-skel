Overview
========

The External Method package provides support for external Python methods,
exposing them as callable objects within a Zope 2 environment.
