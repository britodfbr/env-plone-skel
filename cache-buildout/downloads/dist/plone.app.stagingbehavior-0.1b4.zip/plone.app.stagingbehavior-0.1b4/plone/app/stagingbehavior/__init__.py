
STAGING_RELATION_NAME = 'staging-working-copy'

