This package provides a very advanced sequence sorting feature.
