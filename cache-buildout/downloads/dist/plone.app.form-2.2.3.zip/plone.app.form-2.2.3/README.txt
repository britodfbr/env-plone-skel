plone.app.form
==============

Overview
--------

The plone.app.form package gives Plone the ability to better adapt common
zope.formlib UI style functionality to a more appropriate Plone style.

Features
--------

- **Better integration with zope.formlib.**  The default templates
  distributed with zope.formlib are table-based and don't follow
  common Plone UI patterns, plone.app.form addresses this.
