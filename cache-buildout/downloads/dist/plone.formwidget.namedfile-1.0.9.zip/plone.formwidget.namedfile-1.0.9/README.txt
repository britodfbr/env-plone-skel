Introduction
============

This package provides z3c.form widgets for file and image upload/download,
with the option of keeping the existing file or replacing it with a new one.

The widgets will act as the default for any NamedFile, NamedBlobFile,
NamedImage or NamedBlobImage field from the plone.namedfile package.

