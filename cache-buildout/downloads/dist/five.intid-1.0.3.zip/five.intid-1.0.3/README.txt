Introduction
============

This package makes it possible to use `zope.intid` (and
consequentially other packages that rely on it such as
``zope.keyreference``) in a Zope2 environment.

.. _zope.intid: http://pypi.python.org/pypi/zope.intid
