"""
BBB: five.localsitemanager/PersistentComponents compatibility support.
"""
USE_LSM = True
