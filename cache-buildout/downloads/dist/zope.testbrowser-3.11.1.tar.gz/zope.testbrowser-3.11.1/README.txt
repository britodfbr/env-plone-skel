``zope.testbrowser`` provides an easy-to-use programmable web browser
with special focus on testing.  It is used in Zope, but it's not Zope
specific at all.  For instance, it can be used to test or otherwise
interact with any web site.

