Please see ./Products/PloneFormGen/README.txt
