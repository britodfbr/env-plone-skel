from Products.PloneTestCase import PloneTestCase as ptc
ptc.setupPloneSite()


class AnalyticsTestCase(ptc.PloneTestCase):
    pass


class AnalyticsFunctionalTestCase(ptc.FunctionalTestCase):
    pass
