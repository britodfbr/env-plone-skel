# -*- coding: utf-8 -*-
# $Id: __init__.py 84132 2009-04-12 21:13:03Z glenfant $
"""collective.monkeypatcher"""
