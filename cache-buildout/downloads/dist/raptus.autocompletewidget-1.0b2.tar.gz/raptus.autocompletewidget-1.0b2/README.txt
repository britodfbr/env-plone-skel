Introduction
============

raptus.autocompletewidget provides an archetypes autocomplete widget based on
the jQuery Autocomplete plugin.
