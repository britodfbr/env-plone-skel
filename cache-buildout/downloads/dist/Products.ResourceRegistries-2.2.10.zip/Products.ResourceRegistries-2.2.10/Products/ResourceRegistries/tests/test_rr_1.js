/* add a comment with unicode
   Übercool! */
window.alert('running')
