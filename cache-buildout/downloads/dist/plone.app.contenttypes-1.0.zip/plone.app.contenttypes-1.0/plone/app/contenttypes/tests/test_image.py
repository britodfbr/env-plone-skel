# -*- coding: utf-8 -*-
import os.path
import unittest2 as unittest

from zope.interface import alsoProvides
from zope.component import createObject
from zope.component import queryUtility

from plone.dexterity.interfaces import IDexterityFTI

from plone.app.testing import SITE_OWNER_NAME
from plone.app.testing import SITE_OWNER_PASSWORD
from plone.testing.z2 import Browser

from plone.app.contenttypes.interfaces import IImage

from plone.app.contenttypes.testing import (
    PLONE_APP_CONTENTTYPES_INTEGRATION_TESTING,
    PLONE_APP_CONTENTTYPES_FUNCTIONAL_TESTING
)

from plone.app.testing import TEST_USER_ID, setRoles
from plone.app.z3cform.interfaces import IPloneFormLayer


def dummy_image():
    from plone.namedfile.file import NamedBlobImage
    filename = os.path.join(os.path.dirname(__file__), u'image.jpg')
    return NamedBlobImage(
        data=open(filename, 'r').read(),
        filename=filename
    )


class ImageIntegrationTest(unittest.TestCase):

    layer = PLONE_APP_CONTENTTYPES_INTEGRATION_TESTING

    def setUp(self):
        self.portal = self.layer['portal']
        self.request = self.layer['request']
        self.request['ACTUAL_URL'] = self.portal.absolute_url()
        setRoles(self.portal, TEST_USER_ID, ['Manager'])

    def test_schema(self):
        fti = queryUtility(
            IDexterityFTI,
            name='Image')
        schema = fti.lookupSchema()
        self.assertEqual(schema.getName(), 'plone_0_Image')

    def test_fti(self):
        fti = queryUtility(
            IDexterityFTI,
            name='Image'
        )
        self.assertNotEquals(None, fti)

    def test_factory(self):
        fti = queryUtility(
            IDexterityFTI,
            name='Image'
        )
        factory = fti.factory
        new_object = createObject(factory)
        self.failUnless(IImage.providedBy(new_object))

    def test_adding(self):
        self.portal.invokeFactory(
            'Image',
            'doc1'
        )
        self.assertTrue(IImage.providedBy(self.portal['doc1']))


class ImageViewIntegrationTest(unittest.TestCase):

    layer = PLONE_APP_CONTENTTYPES_INTEGRATION_TESTING

    def setUp(self):
        self.portal = self.layer['portal']
        self.request = self.layer['request']
        self.request['ACTUAL_URL'] = self.portal.absolute_url()
        setRoles(self.portal, TEST_USER_ID, ['Manager'])
        self.portal.invokeFactory('Image', 'image')
        image = self.portal['image']
        image.title = "My Image"
        image.description = "This is my image."
        image.image = dummy_image()
        self.image = image
        self.request.set('URL', image.absolute_url())
        self.request.set('ACTUAL_URL', image.absolute_url())
        alsoProvides(self.request, IPloneFormLayer)

    def test_image_view(self):
        view = self.image.restrictedTraverse('@@view')

        self.assertTrue(view())
        self.assertEquals(view.request.response.status, 200)
        self.assertTrue('My Image' in view())
        self.assertTrue('This is my image.' in view())

# XXX: Not working. See ImageFunctionalTest test_image_view_fullscreen
# Problem seems to be that the image is not properly uploaded.
#    def test_image_view_fullscreen(self):
#        view = getMultiAdapter(
#            (self.image, self.request),
#            name="image_view_fullscreen"
#        )
#
#        self.assertTrue(view())
#        self.assertEquals(view.request.response.status, 200)
#        self.assertTrue('image.jpg' in view())


class ImageFunctionalTest(unittest.TestCase):

    layer = PLONE_APP_CONTENTTYPES_FUNCTIONAL_TESTING

    def setUp(self):
        app = self.layer['app']
        self.portal = self.layer['portal']
        self.request = self.layer['request']
        self.portal_url = self.portal.absolute_url()
        self.browser = Browser(app)
        self.browser.handleErrors = False
        self.browser.addHeader(
            'Authorization',
            'Basic %s:%s' % (SITE_OWNER_NAME, SITE_OWNER_PASSWORD,)
        )

    def test_add_image(self):
        self.browser.open(self.portal_url)
        self.browser.getLink('Image').click()
        self.browser.getControl(name='form.widgets.title')\
            .value = "My image"
        self.browser.getControl(name='form.widgets.description')\
            .value = "This is my image."
        image_path = os.path.join(os.path.dirname(__file__), "image.jpg")
        image_ctl = self.browser.getControl(name='form.widgets.image')
        image_ctl.add_file(open(image_path), 'image/png', 'image.jpg')
        self.browser.getControl('Save').click()
        self.assertTrue(self.browser.url.endswith('image.jpg/view'))
        self.assertTrue('My image' in self.browser.contents)
        self.assertTrue('This is my image' in self.browser.contents)
        self.assertTrue('image.jpg' in self.browser.contents)

    def test_image_view_fullscreen(self):
        self.browser.open(self.portal_url)
        self.browser.getLink('Image').click()
        self.assertTrue('Title' in self.browser.contents)
        self.assertTrue('Description' in self.browser.contents)
        self.assertTrue('Text' in self.browser.contents)
        self.browser.getControl(name='form.widgets.title')\
            .value = "My image"
        self.browser.getControl(name='form.widgets.description')\
            .value = "This is my image."
        image_path = os.path.join(os.path.dirname(__file__), "image.jpg")
        image_ctl = self.browser.getControl(name='form.widgets.image')
        image_ctl.add_file(open(image_path), 'image/png', 'image.jpg')
        self.browser.getControl('Save').click()
        self.browser.getLink('Click to view full-size image…').click()
        self.assertTrue(
            self.browser.url.endswith('image.jpg/image_view_fullscreen')
        )
        self.assertTrue('My image' in self.browser.contents)
        self.assertTrue('Back to site' in self.browser.contents)


def test_suite():
    return unittest.defaultTestLoader.loadTestsFromName(__name__)
