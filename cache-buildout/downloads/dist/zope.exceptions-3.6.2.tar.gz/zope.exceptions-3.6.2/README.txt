=======================
General Zope Exceptions
=======================

This package contains exception interfaces and implementations which are so
general purpose that they don't belong in Zope application-specific packages.
