"""Testing module containing the tests
for collective.dexteritytextindexer.
"""
