.. admonition:: GitHub-only

    WARNING: If you are reading this on GitHub, DON'T! Read the documentation
    at `api.plone.org <http://api.plone.org/api/exceptions.html>`_
    so you have working references and proper formatting.


.. _plone-api-errors:

plone.api.exc
=============

.. automodule:: plone.api.exc
    :members:
