"""
This should fail:
"""
import grokcore.view as grok
grok.name('viewname')
