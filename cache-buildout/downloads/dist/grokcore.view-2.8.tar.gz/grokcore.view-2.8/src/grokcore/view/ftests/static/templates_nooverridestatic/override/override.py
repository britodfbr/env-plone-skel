

from grokcore.view.ftests.static.templates_nooverridestatic.original.original import CaveView


class PalaceView(CaveView):
    pass
