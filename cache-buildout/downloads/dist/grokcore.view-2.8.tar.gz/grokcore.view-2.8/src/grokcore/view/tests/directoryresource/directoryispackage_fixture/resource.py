import grokcore.view

class DirectoryResourceFoo(grokcore.view.DirectoryResource):
    grokcore.view.path('foo')
