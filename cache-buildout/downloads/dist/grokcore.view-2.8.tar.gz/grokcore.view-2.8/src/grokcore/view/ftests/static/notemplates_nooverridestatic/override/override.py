

from grokcore.view.ftests.static.notemplates_nooverridestatic.original.original import CaveView


class PalaceView(CaveView):
    pass
