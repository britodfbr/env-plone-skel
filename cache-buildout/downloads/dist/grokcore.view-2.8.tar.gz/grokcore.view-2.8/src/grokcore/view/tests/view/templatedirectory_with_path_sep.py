"""
You can not use path separator in templatedir directive:

  >>> import grokcore.view.tests.view.templatedirectory_with_path_sep_fixture
  Traceback (most recent call last):
    ...
  GrokImportError: The 'templatedir' directive can not contain path separator.


"""
