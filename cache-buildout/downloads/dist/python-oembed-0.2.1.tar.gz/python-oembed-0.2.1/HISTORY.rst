History
=======

0.2.1 (2011-12-29)
------------------

* Fix build problems in setup.py

0.2.0 (2011-10-20)
------------------

* Update code format
* Improve import selection of JSON and XML libraries
* Remove unused files

0.1.2 (2009-07-28)
------------------

* Bugfix: resolved issue #1
* Added test case to the URL matching

0.1.1 (2009-09-08)
------------------

* Fixed mime-type check. It failed when more tokens where present in the content-type.
* Added new mime-type "application/xml".
* Changed minor error on package descriptor.

0.1.0 (2008-09-05)
------------------

* First release