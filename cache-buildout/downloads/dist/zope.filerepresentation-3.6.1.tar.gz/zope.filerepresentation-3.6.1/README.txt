==============================
File Representation Interfaces
==============================

Overview
--------

File-system representation interfaces.

The interfaces defined here are used for file-system and file-system-like
representations of objects, such as file-system synchronization, FTP, PUT, and
WebDAV.
