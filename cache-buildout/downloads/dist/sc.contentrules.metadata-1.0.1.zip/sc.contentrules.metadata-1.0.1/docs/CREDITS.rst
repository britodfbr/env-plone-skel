Contributors
------------

 - Érico Andrei [ericof] -- Initial idea
 - Héctor Velarde [hvelarde]


You can find an updated list of package contributors on `GitHub`_.

Development sponsored by OpenMultimedia and Simples Consultoria.

.. _`GitHub`: https://github.com/simplesconsultoria/sc.contentrules.metadata/contributors
