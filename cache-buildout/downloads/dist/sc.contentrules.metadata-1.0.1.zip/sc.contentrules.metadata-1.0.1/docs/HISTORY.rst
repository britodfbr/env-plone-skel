Changelog
------------

1.0.1 (unreleased)
^^^^^^^^^^^^^^^^^^^^

- Add translations to plone domain.
  [ericof]

- Add Brazilian Portuguese translation.
  [ericof]

1.0 (2013-04-13)
^^^^^^^^^^^^^^^^^^

- Support Plone 4.3 [ericof]


1.0b2 (2013-01-15)
^^^^^^^^^^^^^^^^^^

- Test compatibility with Plone 4.3. [hvelarde]

- Fix package distribution. [hvelarde]


1.0b1 (2013-01-14)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

- Initial release
  [ericof]
