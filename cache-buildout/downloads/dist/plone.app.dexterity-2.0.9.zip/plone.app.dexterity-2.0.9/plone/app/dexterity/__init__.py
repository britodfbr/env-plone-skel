import zope.i18nmessageid
MessageFactory = zope.i18nmessageid.MessageFactory('plone.app.dexterity')
PloneMessageFactory = zope.i18nmessageid.MessageFactory('plone')
