from Products.CMFPlone.FactoryTool import FactoryTool

del FactoryTool.f
