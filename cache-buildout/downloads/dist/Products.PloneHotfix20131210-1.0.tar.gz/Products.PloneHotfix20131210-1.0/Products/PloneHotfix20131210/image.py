from OFS.Image import Image

del Image.tag.im_func.__doc__
