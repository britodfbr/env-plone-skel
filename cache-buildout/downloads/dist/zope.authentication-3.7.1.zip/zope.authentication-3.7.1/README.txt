This package provides a definition of authentication concepts for use in
Zope Framework.
