TALESField Readme

  An Archetype field that stores TALES Expressions

  Further Information

   Visit http://plone.org/products/scriptablefields for documenttion, 
   bug-reports, etc.

  Maintainer

    BlueDynamics Alliance, Klein & Partner KEG, Innsbruck, Austria
    Jens Klein <jens@bluedynamics.com>

  Copyright

    (C) 2005i-2007 Sidnei da Silva, Daniel Nouri and contributors
