This package provides browser views for adding and managing integer id
utility, provided by the ``zope.intid`` package.
