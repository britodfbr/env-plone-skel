Overview
========

An extension to zope.formlib, which allows to group fields into different
fieldsets.
