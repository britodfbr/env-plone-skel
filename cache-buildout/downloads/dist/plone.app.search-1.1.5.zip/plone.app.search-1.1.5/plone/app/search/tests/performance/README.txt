Search results page performance tests

Use:

bin/test -s plone.app.search --tests-pattern=performance

Beware: these tests may move or be renamed.