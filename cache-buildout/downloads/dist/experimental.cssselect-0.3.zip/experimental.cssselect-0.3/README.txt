======================
experimental.cssselect
======================

This package contains an experimental fork of the lxml.cssselect module. The
lxml fork with the same changes is http://github.com/lrowe/lxml
