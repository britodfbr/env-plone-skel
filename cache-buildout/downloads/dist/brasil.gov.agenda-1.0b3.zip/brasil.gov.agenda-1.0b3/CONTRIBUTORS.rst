Contributors
-------------

* Érico Andrei (ericof)
* Felipe Duardo (felipeduardo)
* Danilo Barbato (dbarbato)
* Eduardo Goulart
