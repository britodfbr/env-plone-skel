The ``zope.traversing`` package provides adapteres for resolving
object paths by traversing an object hierarchy.  This also includes
support for traversal namespaces (e.g. ``++view++``, ``++skin++``,
etc.) as well as computing URLs via the ``@@absolute_url`` view.
