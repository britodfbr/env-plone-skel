from Products.CMFDefault.interfaces import ICMFDefaultSkin


class IDefaultPloneLayer(ICMFDefaultSkin):
    """A Zope 3 browser layer corresponding to Plone defaults
    """
