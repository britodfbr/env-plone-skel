*****************************************************
``zdaemon`` process controller for Unix-based systems
*****************************************************

``zdaemon`` is a Unix (Unix, Linux, Mac OS X) Python program that wraps
commands to make them behave as proper daemons.

.. contents::
