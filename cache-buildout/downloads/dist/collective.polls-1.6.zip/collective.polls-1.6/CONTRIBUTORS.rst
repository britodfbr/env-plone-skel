Share and Enjoy
---------------

``collective.polls`` would not have been possible without the contribution of
the following people:

- Franco Pellegrini
- Héctor Velarde
- Érico Andrei
- Rafahela Bazzanella
- Silvestre Huens
- Elio Schmutz
- Timon Tschanz
- Maurits van Rees
- Jean-Michel FRANCOIS
- `WebDesignerDepot`_ (icon)

You can find an updated list of package contributors on `GitHub`_.

Development sponsored by Open Multimedia and `Simples Consultoria`_.

.. _`WebDesignerDepot`: http://www.webdesignerdepot.com/
.. _`GitHub`: https://github.com/collective/collective.polls/contributors
.. _`Simples Consultoria`: http://www.simplesconsultoria.com.br/
