from Products.ATContentTypes.interfaces.interfaces import ITextContent


class IATDocument(ITextContent):
    """AT Document marker interface
    """
