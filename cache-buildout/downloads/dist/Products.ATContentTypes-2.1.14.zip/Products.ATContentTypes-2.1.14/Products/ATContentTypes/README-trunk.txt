ATContentTypes is now maintained in egg-form and has been moved to a new
location in the collective:

  https://svn.plone.org/svn/collective/Products.ATContentTypes
