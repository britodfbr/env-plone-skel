Overview
========

This package integrates five.customerize_ into Plone, which enables site
administrators to customize templates used for Five/Zope-style views,
viewlets and portlets through the web via the ZMI in a way similar to
overriding filesystem-based skin elements via the portal skin "customize"
procedure.

  .. _five.customerize: http://svn.zope.org/five.customerize/

