# -*- coding:utf-8 -*-
from zope.i18nmessageid import MessageFactory as BaseMessageFactory


MessageFactory = BaseMessageFactory('brasil.gov.vcge')
