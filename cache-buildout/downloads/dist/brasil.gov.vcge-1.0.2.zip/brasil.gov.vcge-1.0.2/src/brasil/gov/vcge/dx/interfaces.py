# -*- coding:utf-8 -*-
from zope.interface import Interface


class IVCGEDx(Interface):
    """Marker interface para conteudos com behavior VCGE
    """
