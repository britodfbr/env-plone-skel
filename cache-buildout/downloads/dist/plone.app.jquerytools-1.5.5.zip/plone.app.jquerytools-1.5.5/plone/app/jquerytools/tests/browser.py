from Products.Five import BrowserView

class TestForm(BrowserView):
    pass
