See src/zope/lifecycleevent/README.txt.
