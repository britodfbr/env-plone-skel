"""\
I18N support for zope.formlib

"""
__docformat__ = "reStructuredText"

import zope.i18nmessageid

_ = zope.i18nmessageid.MessageFactory("zope")
