=============
MailingLogger
=============

For full documentation please see:
http://www.simplistix.co.uk/software/python/mailinglogger

If working offline, please consult the documentation source in the
`docs` directory.

Licensing
=========

Copyright (c) 2004-2011 Simplistix Ltd

Copyright (c) 2001-2003 New Information Paradigms Ltd

See docs/license.txt for details.
