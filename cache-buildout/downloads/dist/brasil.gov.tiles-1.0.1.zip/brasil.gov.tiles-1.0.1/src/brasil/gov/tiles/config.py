# -*- coding: utf-8 -*-

PROJECTNAME = 'brasil.gov.tiles'
