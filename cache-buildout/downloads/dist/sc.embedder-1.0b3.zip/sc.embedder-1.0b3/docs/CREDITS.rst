Share and Enjoy
---------------

``sc.embedder`` would not have been possible without the contribution of the
following people:

- Alejandro Pereira
- André Nogueira
- Héctor Velarde
- João S. O. Bueno
- Juan Pablo Giménez
- `et alii`_

Development sponsored by `Simples Consultoria`_.

.. _`Simples Consultoria`: http://www.simplesconsultoria.com.br/
.. _`et alii`: https://github.com/simplesconsultoria/sc.embedder/graphs/contributors
