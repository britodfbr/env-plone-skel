from zope.interface import Interface


class IEmbedderLayer(Interface):
    """ Browser layer
    """
