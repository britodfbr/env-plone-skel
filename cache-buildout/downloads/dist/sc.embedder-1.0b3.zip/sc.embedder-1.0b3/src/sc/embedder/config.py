# -*- coding: utf-8 -*-

PROJECTNAME = 'sc.embedder'
