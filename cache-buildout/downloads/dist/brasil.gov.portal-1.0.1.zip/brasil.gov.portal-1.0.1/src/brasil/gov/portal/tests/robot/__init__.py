# -*- coding:utf-8 -*-
from brasil.gov.portal.tests.robot.acessibilidade import Acessibilidade
