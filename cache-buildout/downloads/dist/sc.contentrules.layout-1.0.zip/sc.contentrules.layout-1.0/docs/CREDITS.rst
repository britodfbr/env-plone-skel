Contributors
-----------------

* Érico Andrei [ericof] -- Initial idea

* Avianca (for the space between seats)
