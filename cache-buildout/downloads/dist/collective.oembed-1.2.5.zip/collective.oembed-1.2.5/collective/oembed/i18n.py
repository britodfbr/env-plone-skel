from zope.i18nmessageid import MessageFactory

messageFactory = MessageFactory('collective.oembed')
_ = messageFactory

jqueryoembed_integration = _(u"Activate jquery.oembed integration")
jqueryoembed_integration_desc = _(u"""If you have installed a jquery.oembed
plugin, you can activate integration""")
