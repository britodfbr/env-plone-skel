tinyMCE.addI18n('en.template_dlg',{
title:"OEmbed",
label:"OEmbed",
desc_label:"Description",
desc:"Insert external content using oembed",
});