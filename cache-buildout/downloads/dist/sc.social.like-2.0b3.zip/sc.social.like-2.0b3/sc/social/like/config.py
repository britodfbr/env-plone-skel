# -*- coding: utf-8 -*-
# File: config.py

__author__ = """Simples Consultoria <products@simplesconsultoria.com.br>"""
__docformat__ = 'plaintext'

PROJECTNAME = 'sc.social.like'
