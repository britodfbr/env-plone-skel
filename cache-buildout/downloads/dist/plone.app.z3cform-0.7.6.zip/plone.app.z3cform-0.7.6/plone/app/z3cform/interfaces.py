from z3c.form.interfaces import IFormLayer

class IPloneFormLayer(IFormLayer):
    """Request layer installed via browserlayer.xml
    """
