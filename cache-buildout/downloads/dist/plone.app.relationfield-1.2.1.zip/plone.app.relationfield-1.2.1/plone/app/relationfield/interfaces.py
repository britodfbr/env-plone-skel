from z3c.relationfield.interfaces import IHasRelations


class IDexterityHasRelations(IHasRelations):
    """ """
