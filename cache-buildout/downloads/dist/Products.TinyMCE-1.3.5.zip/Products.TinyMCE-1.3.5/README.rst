Documentation at http://readthedocs.org/docs/productstinymce/
