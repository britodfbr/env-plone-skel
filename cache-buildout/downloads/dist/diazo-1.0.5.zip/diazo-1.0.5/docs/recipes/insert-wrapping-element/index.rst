Insert wrapping element
=======================

This recipe demonstrates the insertion of a wrapping element around multiple
tags.

Rules
-----

.. literalinclude:: rules.xml
   :language: xml

Theme
-----

.. literalinclude:: theme.html
   :language: html

Content
-------

.. literalinclude:: content.html
   :language: html

Output
------

.. literalinclude:: output.html
   :language: html
