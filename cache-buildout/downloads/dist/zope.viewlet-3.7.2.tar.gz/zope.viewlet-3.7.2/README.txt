Viewlets provide a generic framework for building pluggable user interfaces.
