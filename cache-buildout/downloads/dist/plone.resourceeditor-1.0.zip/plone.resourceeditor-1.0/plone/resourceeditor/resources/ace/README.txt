This directory contains the minified ACE 1.0 release.

See ace.ajax.org for details.