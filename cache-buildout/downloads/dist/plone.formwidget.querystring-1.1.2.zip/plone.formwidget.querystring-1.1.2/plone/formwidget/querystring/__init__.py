from zope.i18nmessageid import MessageFactory
MessageFactory = MessageFactory('plone')

from plone.formwidget.querystring.widget import QueryStringFieldWidget
