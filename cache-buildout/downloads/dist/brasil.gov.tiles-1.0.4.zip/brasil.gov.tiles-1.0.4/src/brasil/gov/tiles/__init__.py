# -*- coding: utf-8 -*-
from brasil.gov.tiles import patches
from zope.i18nmessageid import MessageFactory

_ = MessageFactory('brasil.gov.tiles')


patches.run()
