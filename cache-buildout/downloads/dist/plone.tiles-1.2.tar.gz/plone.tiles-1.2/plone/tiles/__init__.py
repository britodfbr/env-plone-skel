# Convenience imports

from plone.tiles.tile import Tile, PersistentTile
assert Tile, PersistentTile  # silence pyflakes
