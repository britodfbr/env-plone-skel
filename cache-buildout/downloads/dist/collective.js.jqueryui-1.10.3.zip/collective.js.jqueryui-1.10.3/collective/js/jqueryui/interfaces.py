from zope.interface import Interface
from collective.js.jqueryui.controlpanel import IJQueryUIPlugins, IJQueryUICSS


class IJqueryUILayer(Interface):
    """Browser layer"""
