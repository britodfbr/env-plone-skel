Overview
========

Missing provides special objects used in some Zope2 internals like the ZCatalog.
