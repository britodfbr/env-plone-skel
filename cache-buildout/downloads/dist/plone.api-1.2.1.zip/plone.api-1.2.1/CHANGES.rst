see docs/CHANGES.rst
