.. admonition:: GitHub-only

    WARNING: If you are reading this on GitHub, DON'T! Read the documentation
    at `api.plone.org <http://api.plone.org/api/group.html>`_
    so you have working references and proper formatting.


.. _plone-api-group:

plone.api.group
===============

.. automodule:: plone.api.group
    :members:
