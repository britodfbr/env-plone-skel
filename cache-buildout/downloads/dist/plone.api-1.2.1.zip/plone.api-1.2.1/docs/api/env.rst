.. admonition:: GitHub-only

    WARNING: If you are reading this on GitHub, DON'T! Read the documentation
    at `api.plone.org <http://api.plone.org/api/env.html>`_
    so you have working references and proper formatting.


.. _plone-api-env:

plone.api.env
=============

.. automodule:: plone.api.env
    :members:
