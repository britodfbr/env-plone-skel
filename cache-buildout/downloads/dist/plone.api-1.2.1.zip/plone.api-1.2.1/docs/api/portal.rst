.. admonition:: GitHub-only

    WARNING: If you are reading this on GitHub, DON'T! Read the documentation
    at `api.plone.org <http://api.plone.org/api/portal.html>`_
    so you have working references and proper formatting.


.. _plone-api-portal:

plone.api.portal
================

.. automodule:: plone.api.portal
    :members:
