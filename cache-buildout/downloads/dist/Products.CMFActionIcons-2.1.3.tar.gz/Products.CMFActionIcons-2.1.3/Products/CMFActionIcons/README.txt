=========================
 Products.CMFActionIcons
=========================

.. contents::

NOTE
====

Starting with CMFCore and CMFDefault versions 2.2.0 the CMFActionIcons
product is obsolete. Its functionality has been folded into the
core CMF packages.


Overview
========

The action icons tool provides a centralized registry mapping CMF
"actions" (identified by their category and ID) to additional presentation
metadata (display title and icon).  The skins here show alternative
mechanisms for using this metadata within a site template.
