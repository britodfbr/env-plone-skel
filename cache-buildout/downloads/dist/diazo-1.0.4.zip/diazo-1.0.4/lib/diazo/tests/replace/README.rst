Basic replace
=============

Use <replace> to replace a theme node with a content node.  Put an
attribute on the theme node to ensure that the result doesn't have the
attribute.
