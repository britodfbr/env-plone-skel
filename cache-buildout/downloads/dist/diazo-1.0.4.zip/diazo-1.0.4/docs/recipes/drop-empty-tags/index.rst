Drop empty tags
===============

This recipe demonstrates dropping of empty paragraph tags, including those
that contain only whitespace or a single non-breaking space.

Rules
-----

.. literalinclude:: rules.xml
   :language: xml

Theme
-----

.. literalinclude:: theme.html
   :language: html

Content
-------

.. literalinclude:: content.html
   :language: html

Output
------

.. literalinclude:: output.html
   :language: html
