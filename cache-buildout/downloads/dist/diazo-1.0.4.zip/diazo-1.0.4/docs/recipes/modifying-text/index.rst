Modifying text
==============

This recipe demonstrates the modification of some text.

Rules
-----

.. literalinclude:: rules.xml
   :language: xml

Theme
-----

.. literalinclude:: theme.html
   :language: html

Content
-------

.. literalinclude:: content.html
   :language: html

Output
------

.. literalinclude:: output.html
   :language: html
