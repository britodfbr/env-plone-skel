This package provides the old form framework for Zope 3. It also
implements a few high-level ZCML directives for declaring forms. More
advanced alternatives are implemented in ``zope.formlib`` and
``z3c.form``. The widgets that were defined in here were moved to
``zope.formlib``. Version 4.0 and newer are maintained for backwards
compatibility reasons only.

