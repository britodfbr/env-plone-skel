"""\
I18N support for zope.app.form.browser.

"""
# BBB implementation moved to zope.formlib.i18n
from zope.formlib.i18n import _
