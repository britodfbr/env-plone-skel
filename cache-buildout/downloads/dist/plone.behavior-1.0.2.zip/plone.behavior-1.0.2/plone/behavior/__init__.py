# Convenience import

from plone.behavior.annotation import AnnotationStorage